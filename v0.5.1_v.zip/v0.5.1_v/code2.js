gdjs.LoadCode = {};
gdjs.LoadCode.localVariables = [];
gdjs.LoadCode.GDKnobObjects1= [];
gdjs.LoadCode.GDKnobObjects2= [];
gdjs.LoadCode.GDKnobObjects3= [];
gdjs.LoadCode.GDNewToggleSwitchObjects1= [];
gdjs.LoadCode.GDNewToggleSwitchObjects2= [];
gdjs.LoadCode.GDNewToggleSwitchObjects3= [];
gdjs.LoadCode.GDInstuctionsObjects1= [];
gdjs.LoadCode.GDInstuctionsObjects2= [];
gdjs.LoadCode.GDInstuctionsObjects3= [];
gdjs.LoadCode.GDDetail_9595modeObjects1= [];
gdjs.LoadCode.GDDetail_9595modeObjects2= [];
gdjs.LoadCode.GDDetail_9595modeObjects3= [];
gdjs.LoadCode.GDINSTObjects1= [];
gdjs.LoadCode.GDINSTObjects2= [];
gdjs.LoadCode.GDINSTObjects3= [];
gdjs.LoadCode.GDSearchbarObjects1= [];
gdjs.LoadCode.GDSearchbarObjects2= [];
gdjs.LoadCode.GDSearchbarObjects3= [];
gdjs.LoadCode.GDResultsObjects1= [];
gdjs.LoadCode.GDResultsObjects2= [];
gdjs.LoadCode.GDResultsObjects3= [];
gdjs.LoadCode.GDKnob_9595overlayObjects1= [];
gdjs.LoadCode.GDKnob_9595overlayObjects2= [];
gdjs.LoadCode.GDKnob_9595overlayObjects3= [];
gdjs.LoadCode.GDDetail_9595overlay_9595autoplayObjects1= [];
gdjs.LoadCode.GDDetail_9595overlay_9595autoplayObjects2= [];
gdjs.LoadCode.GDDetail_9595overlay_9595autoplayObjects3= [];
gdjs.LoadCode.GDGlobal_9595PlayObjects1= [];
gdjs.LoadCode.GDGlobal_9595PlayObjects2= [];
gdjs.LoadCode.GDGlobal_9595PlayObjects3= [];
gdjs.LoadCode.GDGlobal_9595EditorObjects1= [];
gdjs.LoadCode.GDGlobal_9595EditorObjects2= [];
gdjs.LoadCode.GDGlobal_9595EditorObjects3= [];
gdjs.LoadCode.GDGlobal_9595HomeObjects1= [];
gdjs.LoadCode.GDGlobal_9595HomeObjects2= [];
gdjs.LoadCode.GDGlobal_9595HomeObjects3= [];
gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects1= [];
gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2= [];
gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects3= [];
gdjs.LoadCode.GDGlobal_9595Blank_9595KnobObjects1= [];
gdjs.LoadCode.GDGlobal_9595Blank_9595KnobObjects2= [];
gdjs.LoadCode.GDGlobal_9595Blank_9595KnobObjects3= [];
gdjs.LoadCode.GDGlobal_9595BaseObjects1= [];
gdjs.LoadCode.GDGlobal_9595BaseObjects2= [];
gdjs.LoadCode.GDGlobal_9595BaseObjects3= [];
gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects1= [];
gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects2= [];
gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects3= [];
gdjs.LoadCode.GDAutoPlayObjects1= [];
gdjs.LoadCode.GDAutoPlayObjects2= [];
gdjs.LoadCode.GDAutoPlayObjects3= [];
gdjs.LoadCode.GDLoading_9595alertObjects1= [];
gdjs.LoadCode.GDLoading_9595alertObjects2= [];
gdjs.LoadCode.GDLoading_9595alertObjects3= [];
gdjs.LoadCode.GDTri_9595Blank_9595Objects1= [];
gdjs.LoadCode.GDTri_9595Blank_9595Objects2= [];
gdjs.LoadCode.GDTri_9595Blank_9595Objects3= [];
gdjs.LoadCode.GDSnapShotObjects1= [];
gdjs.LoadCode.GDSnapShotObjects2= [];
gdjs.LoadCode.GDSnapShotObjects3= [];
gdjs.LoadCode.GDBackgroundObjects1= [];
gdjs.LoadCode.GDBackgroundObjects2= [];
gdjs.LoadCode.GDBackgroundObjects3= [];
gdjs.LoadCode.GDfadeObjects1= [];
gdjs.LoadCode.GDfadeObjects2= [];
gdjs.LoadCode.GDfadeObjects3= [];


gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595HomeObjects2Objects = Hashtable.newFrom({"Global_Home": gdjs.LoadCode.GDGlobal_9595HomeObjects2});
gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595PlayObjects2Objects = Hashtable.newFrom({"Global_Play": gdjs.LoadCode.GDGlobal_9595PlayObjects2});
gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595HomeObjects2Objects = Hashtable.newFrom({"Global_Home": gdjs.LoadCode.GDGlobal_9595HomeObjects2});
gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595HomeObjects2Objects = Hashtable.newFrom({"Global_Home": gdjs.LoadCode.GDGlobal_9595HomeObjects2});
gdjs.LoadCode.eventsList0 = function(runtimeScene) {

{

/* Reuse gdjs.LoadCode.GDGlobal_9595HomeObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595HomeObjects2Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Synth Selector");
}}

}


};gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595HomeObjects2Objects = Hashtable.newFrom({"Global_Home": gdjs.LoadCode.GDGlobal_9595HomeObjects2});
gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595HomeObjects2Objects = Hashtable.newFrom({"Global_Home": gdjs.LoadCode.GDGlobal_9595HomeObjects2});
gdjs.LoadCode.eventsList1 = function(runtimeScene) {

{

/* Reuse gdjs.LoadCode.GDGlobal_9595HomeObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasDoubleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595HomeObjects2Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Synth Selector", false);
}}

}


};gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595EditorObjects1Objects = Hashtable.newFrom({"Global_Editor": gdjs.LoadCode.GDGlobal_9595EditorObjects1});
gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595EditorObjects1Objects = Hashtable.newFrom({"Global_Editor": gdjs.LoadCode.GDGlobal_9595EditorObjects1});
gdjs.LoadCode.eventsList2 = function(runtimeScene) {

{

/* Reuse gdjs.LoadCode.GDGlobal_9595EditorObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595EditorObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Editor");
}}

}


};gdjs.LoadCode.eventsList3 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Home"), gdjs.LoadCode.GDGlobal_9595HomeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595HomeObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2);
{for(var i = 0, len = gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Play"), gdjs.LoadCode.GDGlobal_9595PlayObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595PlayObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2);
{for(var i = 0, len = gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2[i].getBehavior("Animation").setAnimationIndex(2);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Home"), gdjs.LoadCode.GDGlobal_9595HomeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595HomeObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2);
{for(var i = 0, len = gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}
{ //Subevents
gdjs.LoadCode.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Home"), gdjs.LoadCode.GDGlobal_9595HomeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595HomeObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2);
{for(var i = 0, len = gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}
{ //Subevents
gdjs.LoadCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Editor"), gdjs.LoadCode.GDGlobal_9595EditorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595EditorObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects1);
{for(var i = 0, len = gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects1.length ;i < len;++i) {
    gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects1[i].getBehavior("Animation").setAnimationIndex(3);
}
}
{ //Subevents
gdjs.LoadCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.LoadCode.eventsList4 = function(runtimeScene) {

{



}


};gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595PlayObjects2Objects = Hashtable.newFrom({"Global_Play": gdjs.LoadCode.GDGlobal_9595PlayObjects2});
gdjs.LoadCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Global_Play"), gdjs.LoadCode.GDGlobal_9595PlayObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595PlayObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "E Keys4.wav", 10, false, 50, 1);
}}

}


};gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595PlayObjects2Objects = Hashtable.newFrom({"Global_Play": gdjs.LoadCode.GDGlobal_9595PlayObjects2});
gdjs.LoadCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Global_Play"), gdjs.LoadCode.GDGlobal_9595PlayObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595PlayObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Simple Pluck -2.wav", 10, false, 50, 1);
}}

}


};gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595PlayObjects2Objects = Hashtable.newFrom({"Global_Play": gdjs.LoadCode.GDGlobal_9595PlayObjects2});
gdjs.LoadCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Global_Play"), gdjs.LoadCode.GDGlobal_9595PlayObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595PlayObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Ow - Ahh1.wav", 10, false, 50, 1);
}}

}


};gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595PlayObjects1Objects = Hashtable.newFrom({"Global_Play": gdjs.LoadCode.GDGlobal_9595PlayObjects1});
gdjs.LoadCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Global_Play"), gdjs.LoadCode.GDGlobal_9595PlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoadCode.mapOfGDgdjs_9546LoadCode_9546GDGlobal_95959595PlayObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Boom Kick.wav", 10, false, 50, 1);
}}

}


};gdjs.LoadCode.eventsList9 = function(runtimeScene) {

{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Searchbar"), gdjs.LoadCode.GDSearchbarObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoadCode.GDSearchbarObjects2.length;i<l;++i) {
    if ( gdjs.LoadCode.GDSearchbarObjects2[i].getBehavior("Text").getText() == "" ) {
        isConditionTrue_0 = true;
        gdjs.LoadCode.GDSearchbarObjects2[k] = gdjs.LoadCode.GDSearchbarObjects2[i];
        ++k;
    }
}
gdjs.LoadCode.GDSearchbarObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("INST"), gdjs.LoadCode.GDINSTObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knob_overlay"), gdjs.LoadCode.GDKnob_9595overlayObjects2);
{for(var i = 0, len = gdjs.LoadCode.GDKnob_9595overlayObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDKnob_9595overlayObjects2[i].getBehavior("Animation").setAnimationName("Blank");
}
}{for(var i = 0, len = gdjs.LoadCode.GDINSTObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDINSTObjects2[i].getBehavior("Text").setText("Click the search bar below to look for patch sheets. These are case-sensitive and need to be typed as shown.\n\nSheets: | E_Keys | Ow-Ahh | Simple Pluck | Boom Kick |\n");
}
}
{ //Subevents
gdjs.LoadCode.eventsList4(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() == 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("INST"), gdjs.LoadCode.GDINSTObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knob_overlay"), gdjs.LoadCode.GDKnob_9595overlayObjects2);
{for(var i = 0, len = gdjs.LoadCode.GDKnob_9595overlayObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDKnob_9595overlayObjects2[i].getBehavior("Animation").setAnimationName("E_Keys");
}
}{for(var i = 0, len = gdjs.LoadCode.GDINSTObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDINSTObjects2[i].getBehavior("Text").setText("E_Keys\n\nNo patch details given");
}
}
{ //Subevents
gdjs.LoadCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() == 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("INST"), gdjs.LoadCode.GDINSTObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knob_overlay"), gdjs.LoadCode.GDKnob_9595overlayObjects2);
{for(var i = 0, len = gdjs.LoadCode.GDKnob_9595overlayObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDKnob_9595overlayObjects2[i].getBehavior("Animation").setAnimationName("Simple Pluck");
}
}{for(var i = 0, len = gdjs.LoadCode.GDINSTObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDINSTObjects2[i].getBehavior("Text").setText("Simple Pluck\n\nMIX CV >> MULTI, EXT AUDIO >> OSC PULSE, VCF CUTOFF >> KB CV, MIX 2 >> LFO TRI, VC MIX >> ENV, MULTI >> VC MIX\n");
}
}
{ //Subevents
gdjs.LoadCode.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() == 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("INST"), gdjs.LoadCode.GDINSTObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knob_overlay"), gdjs.LoadCode.GDKnob_9595overlayObjects2);
{for(var i = 0, len = gdjs.LoadCode.GDKnob_9595overlayObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDKnob_9595overlayObjects2[i].getBehavior("Animation").setAnimationName("Ow-Ahh");
}
}{for(var i = 0, len = gdjs.LoadCode.GDINSTObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDINSTObjects2[i].getBehavior("Text").setText("Ow-Ahh\n\nNo patch details given");
}
}
{ //Subevents
gdjs.LoadCode.eventsList7(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() == 4);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("INST"), gdjs.LoadCode.GDINSTObjects1);
gdjs.copyArray(runtimeScene.getObjects("Knob_overlay"), gdjs.LoadCode.GDKnob_9595overlayObjects1);
{for(var i = 0, len = gdjs.LoadCode.GDKnob_9595overlayObjects1.length ;i < len;++i) {
    gdjs.LoadCode.GDKnob_9595overlayObjects1[i].getBehavior("Animation").setAnimationName("Boom Kick");
}
}{for(var i = 0, len = gdjs.LoadCode.GDINSTObjects1.length ;i < len;++i) {
    gdjs.LoadCode.GDINSTObjects1[i].getBehavior("Text").setText("Boom Kick\n\nVCF CUTOFF >> KB CV");
}
}
{ //Subevents
gdjs.LoadCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.LoadCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 10));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loading_alert"), gdjs.LoadCode.GDLoading_9595alertObjects2);
{for(var i = 0, len = gdjs.LoadCode.GDLoading_9595alertObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDLoading_9595alertObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.LoadCode.GDLoading_9595alertObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDLoading_9595alertObjects2[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 10);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loading_alert"), gdjs.LoadCode.GDLoading_9595alertObjects1);
{for(var i = 0, len = gdjs.LoadCode.GDLoading_9595alertObjects1.length ;i < len;++i) {
    gdjs.LoadCode.GDLoading_9595alertObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.LoadCode.GDLoading_9595alertObjects1.length ;i < len;++i) {
    gdjs.LoadCode.GDLoading_9595alertObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


};gdjs.LoadCode.eventsList11 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Detail_mode"), gdjs.LoadCode.GDDetail_9595modeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoadCode.GDDetail_9595modeObjects2.length;i<l;++i) {
    if ( gdjs.LoadCode.GDDetail_9595modeObjects2[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LoadCode.GDDetail_9595modeObjects2[k] = gdjs.LoadCode.GDDetail_9595modeObjects2[i];
        ++k;
    }
}
gdjs.LoadCode.GDDetail_9595modeObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Lite"), gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects2);
{for(var i = 0, len = gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects2.length ;i < len;++i) {
    gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Detail_mode"), gdjs.LoadCode.GDDetail_9595modeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoadCode.GDDetail_9595modeObjects1.length;i<l;++i) {
    if ( !(gdjs.LoadCode.GDDetail_9595modeObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.LoadCode.GDDetail_9595modeObjects1[k] = gdjs.LoadCode.GDDetail_9595modeObjects1[i];
        ++k;
    }
}
gdjs.LoadCode.GDDetail_9595modeObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Lite"), gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects1);
{for(var i = 0, len = gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects1.length ;i < len;++i) {
    gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


};gdjs.LoadCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loading_alert"), gdjs.LoadCode.GDLoading_9595alertObjects1);
{gdjs.evtTools.window.setWindowTitle(runtimeScene, "The Crave Patch Project");
}{for(var i = 0, len = gdjs.LoadCode.GDLoading_9595alertObjects1.length ;i < len;++i) {
    gdjs.LoadCode.GDLoading_9595alertObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "E Keys4.wav");
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "Ow - Ahh1.wav");
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "Simple Pluck -2.wav");
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "Boom Kick.wav");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
}

}


{


gdjs.LoadCode.eventsList3(runtimeScene);
}


{


gdjs.LoadCode.eventsList9(runtimeScene);
}


{


gdjs.LoadCode.eventsList10(runtimeScene);
}


{


gdjs.LoadCode.eventsList11(runtimeScene);
}


};

gdjs.LoadCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LoadCode.GDKnobObjects1.length = 0;
gdjs.LoadCode.GDKnobObjects2.length = 0;
gdjs.LoadCode.GDKnobObjects3.length = 0;
gdjs.LoadCode.GDNewToggleSwitchObjects1.length = 0;
gdjs.LoadCode.GDNewToggleSwitchObjects2.length = 0;
gdjs.LoadCode.GDNewToggleSwitchObjects3.length = 0;
gdjs.LoadCode.GDInstuctionsObjects1.length = 0;
gdjs.LoadCode.GDInstuctionsObjects2.length = 0;
gdjs.LoadCode.GDInstuctionsObjects3.length = 0;
gdjs.LoadCode.GDDetail_9595modeObjects1.length = 0;
gdjs.LoadCode.GDDetail_9595modeObjects2.length = 0;
gdjs.LoadCode.GDDetail_9595modeObjects3.length = 0;
gdjs.LoadCode.GDINSTObjects1.length = 0;
gdjs.LoadCode.GDINSTObjects2.length = 0;
gdjs.LoadCode.GDINSTObjects3.length = 0;
gdjs.LoadCode.GDSearchbarObjects1.length = 0;
gdjs.LoadCode.GDSearchbarObjects2.length = 0;
gdjs.LoadCode.GDSearchbarObjects3.length = 0;
gdjs.LoadCode.GDResultsObjects1.length = 0;
gdjs.LoadCode.GDResultsObjects2.length = 0;
gdjs.LoadCode.GDResultsObjects3.length = 0;
gdjs.LoadCode.GDKnob_9595overlayObjects1.length = 0;
gdjs.LoadCode.GDKnob_9595overlayObjects2.length = 0;
gdjs.LoadCode.GDKnob_9595overlayObjects3.length = 0;
gdjs.LoadCode.GDDetail_9595overlay_9595autoplayObjects1.length = 0;
gdjs.LoadCode.GDDetail_9595overlay_9595autoplayObjects2.length = 0;
gdjs.LoadCode.GDDetail_9595overlay_9595autoplayObjects3.length = 0;
gdjs.LoadCode.GDGlobal_9595PlayObjects1.length = 0;
gdjs.LoadCode.GDGlobal_9595PlayObjects2.length = 0;
gdjs.LoadCode.GDGlobal_9595PlayObjects3.length = 0;
gdjs.LoadCode.GDGlobal_9595EditorObjects1.length = 0;
gdjs.LoadCode.GDGlobal_9595EditorObjects2.length = 0;
gdjs.LoadCode.GDGlobal_9595EditorObjects3.length = 0;
gdjs.LoadCode.GDGlobal_9595HomeObjects1.length = 0;
gdjs.LoadCode.GDGlobal_9595HomeObjects2.length = 0;
gdjs.LoadCode.GDGlobal_9595HomeObjects3.length = 0;
gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects1.length = 0;
gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2.length = 0;
gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects3.length = 0;
gdjs.LoadCode.GDGlobal_9595Blank_9595KnobObjects1.length = 0;
gdjs.LoadCode.GDGlobal_9595Blank_9595KnobObjects2.length = 0;
gdjs.LoadCode.GDGlobal_9595Blank_9595KnobObjects3.length = 0;
gdjs.LoadCode.GDGlobal_9595BaseObjects1.length = 0;
gdjs.LoadCode.GDGlobal_9595BaseObjects2.length = 0;
gdjs.LoadCode.GDGlobal_9595BaseObjects3.length = 0;
gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects1.length = 0;
gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects2.length = 0;
gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects3.length = 0;
gdjs.LoadCode.GDAutoPlayObjects1.length = 0;
gdjs.LoadCode.GDAutoPlayObjects2.length = 0;
gdjs.LoadCode.GDAutoPlayObjects3.length = 0;
gdjs.LoadCode.GDLoading_9595alertObjects1.length = 0;
gdjs.LoadCode.GDLoading_9595alertObjects2.length = 0;
gdjs.LoadCode.GDLoading_9595alertObjects3.length = 0;
gdjs.LoadCode.GDTri_9595Blank_9595Objects1.length = 0;
gdjs.LoadCode.GDTri_9595Blank_9595Objects2.length = 0;
gdjs.LoadCode.GDTri_9595Blank_9595Objects3.length = 0;
gdjs.LoadCode.GDSnapShotObjects1.length = 0;
gdjs.LoadCode.GDSnapShotObjects2.length = 0;
gdjs.LoadCode.GDSnapShotObjects3.length = 0;
gdjs.LoadCode.GDBackgroundObjects1.length = 0;
gdjs.LoadCode.GDBackgroundObjects2.length = 0;
gdjs.LoadCode.GDBackgroundObjects3.length = 0;
gdjs.LoadCode.GDfadeObjects1.length = 0;
gdjs.LoadCode.GDfadeObjects2.length = 0;
gdjs.LoadCode.GDfadeObjects3.length = 0;

gdjs.LoadCode.eventsList12(runtimeScene);
gdjs.LoadCode.GDKnobObjects1.length = 0;
gdjs.LoadCode.GDKnobObjects2.length = 0;
gdjs.LoadCode.GDKnobObjects3.length = 0;
gdjs.LoadCode.GDNewToggleSwitchObjects1.length = 0;
gdjs.LoadCode.GDNewToggleSwitchObjects2.length = 0;
gdjs.LoadCode.GDNewToggleSwitchObjects3.length = 0;
gdjs.LoadCode.GDInstuctionsObjects1.length = 0;
gdjs.LoadCode.GDInstuctionsObjects2.length = 0;
gdjs.LoadCode.GDInstuctionsObjects3.length = 0;
gdjs.LoadCode.GDDetail_9595modeObjects1.length = 0;
gdjs.LoadCode.GDDetail_9595modeObjects2.length = 0;
gdjs.LoadCode.GDDetail_9595modeObjects3.length = 0;
gdjs.LoadCode.GDINSTObjects1.length = 0;
gdjs.LoadCode.GDINSTObjects2.length = 0;
gdjs.LoadCode.GDINSTObjects3.length = 0;
gdjs.LoadCode.GDSearchbarObjects1.length = 0;
gdjs.LoadCode.GDSearchbarObjects2.length = 0;
gdjs.LoadCode.GDSearchbarObjects3.length = 0;
gdjs.LoadCode.GDResultsObjects1.length = 0;
gdjs.LoadCode.GDResultsObjects2.length = 0;
gdjs.LoadCode.GDResultsObjects3.length = 0;
gdjs.LoadCode.GDKnob_9595overlayObjects1.length = 0;
gdjs.LoadCode.GDKnob_9595overlayObjects2.length = 0;
gdjs.LoadCode.GDKnob_9595overlayObjects3.length = 0;
gdjs.LoadCode.GDDetail_9595overlay_9595autoplayObjects1.length = 0;
gdjs.LoadCode.GDDetail_9595overlay_9595autoplayObjects2.length = 0;
gdjs.LoadCode.GDDetail_9595overlay_9595autoplayObjects3.length = 0;
gdjs.LoadCode.GDGlobal_9595PlayObjects1.length = 0;
gdjs.LoadCode.GDGlobal_9595PlayObjects2.length = 0;
gdjs.LoadCode.GDGlobal_9595PlayObjects3.length = 0;
gdjs.LoadCode.GDGlobal_9595EditorObjects1.length = 0;
gdjs.LoadCode.GDGlobal_9595EditorObjects2.length = 0;
gdjs.LoadCode.GDGlobal_9595EditorObjects3.length = 0;
gdjs.LoadCode.GDGlobal_9595HomeObjects1.length = 0;
gdjs.LoadCode.GDGlobal_9595HomeObjects2.length = 0;
gdjs.LoadCode.GDGlobal_9595HomeObjects3.length = 0;
gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects1.length = 0;
gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects2.length = 0;
gdjs.LoadCode.GDGlobal_9595Top_9595MenuObjects3.length = 0;
gdjs.LoadCode.GDGlobal_9595Blank_9595KnobObjects1.length = 0;
gdjs.LoadCode.GDGlobal_9595Blank_9595KnobObjects2.length = 0;
gdjs.LoadCode.GDGlobal_9595Blank_9595KnobObjects3.length = 0;
gdjs.LoadCode.GDGlobal_9595BaseObjects1.length = 0;
gdjs.LoadCode.GDGlobal_9595BaseObjects2.length = 0;
gdjs.LoadCode.GDGlobal_9595BaseObjects3.length = 0;
gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects1.length = 0;
gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects2.length = 0;
gdjs.LoadCode.GDGlobal_9595Top_9595LiteObjects3.length = 0;
gdjs.LoadCode.GDAutoPlayObjects1.length = 0;
gdjs.LoadCode.GDAutoPlayObjects2.length = 0;
gdjs.LoadCode.GDAutoPlayObjects3.length = 0;
gdjs.LoadCode.GDLoading_9595alertObjects1.length = 0;
gdjs.LoadCode.GDLoading_9595alertObjects2.length = 0;
gdjs.LoadCode.GDLoading_9595alertObjects3.length = 0;
gdjs.LoadCode.GDTri_9595Blank_9595Objects1.length = 0;
gdjs.LoadCode.GDTri_9595Blank_9595Objects2.length = 0;
gdjs.LoadCode.GDTri_9595Blank_9595Objects3.length = 0;
gdjs.LoadCode.GDSnapShotObjects1.length = 0;
gdjs.LoadCode.GDSnapShotObjects2.length = 0;
gdjs.LoadCode.GDSnapShotObjects3.length = 0;
gdjs.LoadCode.GDBackgroundObjects1.length = 0;
gdjs.LoadCode.GDBackgroundObjects2.length = 0;
gdjs.LoadCode.GDBackgroundObjects3.length = 0;
gdjs.LoadCode.GDfadeObjects1.length = 0;
gdjs.LoadCode.GDfadeObjects2.length = 0;
gdjs.LoadCode.GDfadeObjects3.length = 0;


return;

}

gdjs['LoadCode'] = gdjs.LoadCode;
