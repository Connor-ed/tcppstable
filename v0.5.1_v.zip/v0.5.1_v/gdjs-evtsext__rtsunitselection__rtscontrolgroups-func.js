
if (typeof gdjs.evtsExt__RTSUnitSelection__RTSControlGroups !== "undefined") {
  gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups = {};
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex2 = 0;

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 = 0;

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 = 0;

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachObjects2 = [];

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachObjects3 = [];

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachObjects4 = [];

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary2 = null;

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3 = null;

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4 = null;

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTotalCount2 = 0;

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTotalCount3 = 0;

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTotalCount4 = 0;

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects1= [];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2= [];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3= [];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4= [];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5= [];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects6= [];


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList0(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList2 = function(runtimeScene, eventsFunctionContext) {

{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList3 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList2(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList4 = function(runtimeScene, eventsFunctionContext) {

{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList5 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList4(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList6 = function(runtimeScene, eventsFunctionContext) {

{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList7 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList6(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList8 = function(runtimeScene, eventsFunctionContext) {

{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList9 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList8(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList10 = function(runtimeScene, eventsFunctionContext) {

{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 6, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 6, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 6, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList11 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList10(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList12 = function(runtimeScene, eventsFunctionContext) {

{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList13 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList12(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList14 = function(runtimeScene, eventsFunctionContext) {

{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 8, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 8, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 8, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList15 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList14(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList16 = function(runtimeScene, eventsFunctionContext) {

{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 9, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 9, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects5Objects, 9, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList17 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex4];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList16(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList18 = function(runtimeScene, eventsFunctionContext) {

{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__AssignControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList19 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList18(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList20 = function(runtimeScene, eventsFunctionContext) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num1");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(27046148);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList1(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(27049468);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList3(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num3");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(27052812);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList5(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num4");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(27056044);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList7(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num5");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(27059364);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList9(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num6");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(27062604);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList11(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num7");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(27065876);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList13(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num8");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(27069148);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList15(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num9");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(27058836);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList17(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num0");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(27075764);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList19(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList21 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RControl");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList20(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList22 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList23 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList22(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList24 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList25 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList24(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList26 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList27 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList26(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList28 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList29 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList28(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList30 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList31 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList30(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList32 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 6, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 6, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList33 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList32(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList34 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList35 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList34(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList36 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 8, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 8, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList37 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList36(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList38 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 9, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, 9, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects4Objects, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList39 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex3];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList38(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects3Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects3Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects3Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects3Objects = Hashtable.newFrom({"Objects": gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3});
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList40 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects3Objects, 10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects3Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RTSUnitSelection__IsAssignedToControlGroup.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects3Objects, 10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3 */
{gdjs.evtsExt__RTSUnitSelection__SetSelected.func(runtimeScene, gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.mapOfGDgdjs_9546evtsExt_9595_9595RTSUnitSelection_9595_9595RTSControlGroups_9546GDObjectsObjects3Objects, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList41 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Objects"), gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects1);

for (gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex2 = 0;gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex2 < gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects1.length;++gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex2) {
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2.length = 0;


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary2 = gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects1[gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachIndex2];
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2.push(gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList40(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList42 = function(runtimeScene, eventsFunctionContext) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num1");
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList23(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList25(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num3");
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList27(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num4");
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList29(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num5");
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList31(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num6");
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList33(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num7");
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList35(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num8");
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList37(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num9");
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList39(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num0");
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList41(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList43 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "RControl"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl"));
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList42(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList44 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList21(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList43(runtimeScene, eventsFunctionContext);
}


};gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList45 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList44(runtimeScene, eventsFunctionContext);
}


};

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.func = function(runtimeScene, Objects, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
"Objects": Objects
},
  _objectArraysMap: {
"Objects": gdjs.objectsListsToArray(Objects)
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("RTSUnitSelection"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("RTSUnitSelection"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects1.length = 0;
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2.length = 0;
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length = 0;
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.length = 0;
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5.length = 0;
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects6.length = 0;

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.eventsList45(runtimeScene, eventsFunctionContext);
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects1.length = 0;
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects2.length = 0;
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects3.length = 0;
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects4.length = 0;
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects5.length = 0;
gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.GDObjectsObjects6.length = 0;


return;
}

gdjs.evtsExt__RTSUnitSelection__RTSControlGroups.registeredGdjsCallbacks = [];