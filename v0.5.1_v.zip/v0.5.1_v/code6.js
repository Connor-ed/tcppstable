gdjs.SaveCode = {};
gdjs.SaveCode.localVariables = [];
gdjs.SaveCode.GDGlobal_9595PlayObjects1= [];
gdjs.SaveCode.GDGlobal_9595PlayObjects2= [];
gdjs.SaveCode.GDGlobal_9595EditorObjects1= [];
gdjs.SaveCode.GDGlobal_9595EditorObjects2= [];
gdjs.SaveCode.GDGlobal_9595HomeObjects1= [];
gdjs.SaveCode.GDGlobal_9595HomeObjects2= [];
gdjs.SaveCode.GDGlobal_9595Top_9595MenuObjects1= [];
gdjs.SaveCode.GDGlobal_9595Top_9595MenuObjects2= [];
gdjs.SaveCode.GDGlobal_9595Blank_9595KnobObjects1= [];
gdjs.SaveCode.GDGlobal_9595Blank_9595KnobObjects2= [];
gdjs.SaveCode.GDGlobal_9595BaseObjects1= [];
gdjs.SaveCode.GDGlobal_9595BaseObjects2= [];
gdjs.SaveCode.GDGlobal_9595Top_9595LiteObjects1= [];
gdjs.SaveCode.GDGlobal_9595Top_9595LiteObjects2= [];
gdjs.SaveCode.GDAutoPlayObjects1= [];
gdjs.SaveCode.GDAutoPlayObjects2= [];
gdjs.SaveCode.GDLoading_9595alertObjects1= [];
gdjs.SaveCode.GDLoading_9595alertObjects2= [];
gdjs.SaveCode.GDTri_9595Blank_9595Objects1= [];
gdjs.SaveCode.GDTri_9595Blank_9595Objects2= [];
gdjs.SaveCode.GDSnapShotObjects1= [];
gdjs.SaveCode.GDSnapShotObjects2= [];
gdjs.SaveCode.GDBackgroundObjects1= [];
gdjs.SaveCode.GDBackgroundObjects2= [];
gdjs.SaveCode.GDfadeObjects1= [];
gdjs.SaveCode.GDfadeObjects2= [];


gdjs.SaveCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.SaveCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.SaveCode.GDGlobal_9595PlayObjects1.length = 0;
gdjs.SaveCode.GDGlobal_9595PlayObjects2.length = 0;
gdjs.SaveCode.GDGlobal_9595EditorObjects1.length = 0;
gdjs.SaveCode.GDGlobal_9595EditorObjects2.length = 0;
gdjs.SaveCode.GDGlobal_9595HomeObjects1.length = 0;
gdjs.SaveCode.GDGlobal_9595HomeObjects2.length = 0;
gdjs.SaveCode.GDGlobal_9595Top_9595MenuObjects1.length = 0;
gdjs.SaveCode.GDGlobal_9595Top_9595MenuObjects2.length = 0;
gdjs.SaveCode.GDGlobal_9595Blank_9595KnobObjects1.length = 0;
gdjs.SaveCode.GDGlobal_9595Blank_9595KnobObjects2.length = 0;
gdjs.SaveCode.GDGlobal_9595BaseObjects1.length = 0;
gdjs.SaveCode.GDGlobal_9595BaseObjects2.length = 0;
gdjs.SaveCode.GDGlobal_9595Top_9595LiteObjects1.length = 0;
gdjs.SaveCode.GDGlobal_9595Top_9595LiteObjects2.length = 0;
gdjs.SaveCode.GDAutoPlayObjects1.length = 0;
gdjs.SaveCode.GDAutoPlayObjects2.length = 0;
gdjs.SaveCode.GDLoading_9595alertObjects1.length = 0;
gdjs.SaveCode.GDLoading_9595alertObjects2.length = 0;
gdjs.SaveCode.GDTri_9595Blank_9595Objects1.length = 0;
gdjs.SaveCode.GDTri_9595Blank_9595Objects2.length = 0;
gdjs.SaveCode.GDSnapShotObjects1.length = 0;
gdjs.SaveCode.GDSnapShotObjects2.length = 0;
gdjs.SaveCode.GDBackgroundObjects1.length = 0;
gdjs.SaveCode.GDBackgroundObjects2.length = 0;
gdjs.SaveCode.GDfadeObjects1.length = 0;
gdjs.SaveCode.GDfadeObjects2.length = 0;

gdjs.SaveCode.eventsList0(runtimeScene);
gdjs.SaveCode.GDGlobal_9595PlayObjects1.length = 0;
gdjs.SaveCode.GDGlobal_9595PlayObjects2.length = 0;
gdjs.SaveCode.GDGlobal_9595EditorObjects1.length = 0;
gdjs.SaveCode.GDGlobal_9595EditorObjects2.length = 0;
gdjs.SaveCode.GDGlobal_9595HomeObjects1.length = 0;
gdjs.SaveCode.GDGlobal_9595HomeObjects2.length = 0;
gdjs.SaveCode.GDGlobal_9595Top_9595MenuObjects1.length = 0;
gdjs.SaveCode.GDGlobal_9595Top_9595MenuObjects2.length = 0;
gdjs.SaveCode.GDGlobal_9595Blank_9595KnobObjects1.length = 0;
gdjs.SaveCode.GDGlobal_9595Blank_9595KnobObjects2.length = 0;
gdjs.SaveCode.GDGlobal_9595BaseObjects1.length = 0;
gdjs.SaveCode.GDGlobal_9595BaseObjects2.length = 0;
gdjs.SaveCode.GDGlobal_9595Top_9595LiteObjects1.length = 0;
gdjs.SaveCode.GDGlobal_9595Top_9595LiteObjects2.length = 0;
gdjs.SaveCode.GDAutoPlayObjects1.length = 0;
gdjs.SaveCode.GDAutoPlayObjects2.length = 0;
gdjs.SaveCode.GDLoading_9595alertObjects1.length = 0;
gdjs.SaveCode.GDLoading_9595alertObjects2.length = 0;
gdjs.SaveCode.GDTri_9595Blank_9595Objects1.length = 0;
gdjs.SaveCode.GDTri_9595Blank_9595Objects2.length = 0;
gdjs.SaveCode.GDSnapShotObjects1.length = 0;
gdjs.SaveCode.GDSnapShotObjects2.length = 0;
gdjs.SaveCode.GDBackgroundObjects1.length = 0;
gdjs.SaveCode.GDBackgroundObjects2.length = 0;
gdjs.SaveCode.GDfadeObjects1.length = 0;
gdjs.SaveCode.GDfadeObjects2.length = 0;


return;

}

gdjs['SaveCode'] = gdjs.SaveCode;
