gdjs.BootCode = {};
gdjs.BootCode.localVariables = [];
gdjs.BootCode.GDVersion_9595detailsObjects1= [];
gdjs.BootCode.GDVersion_9595detailsObjects2= [];
gdjs.BootCode.GDEditorObjects1= [];
gdjs.BootCode.GDEditorObjects2= [];
gdjs.BootCode.GDM_9595TEXTObjects1= [];
gdjs.BootCode.GDM_9595TEXTObjects2= [];
gdjs.BootCode.GDShareObjects1= [];
gdjs.BootCode.GDShareObjects2= [];
gdjs.BootCode.GDLoadObjects1= [];
gdjs.BootCode.GDLoadObjects2= [];
gdjs.BootCode.GDCreditsObjects1= [];
gdjs.BootCode.GDCreditsObjects2= [];
gdjs.BootCode.GDHelpObjects1= [];
gdjs.BootCode.GDHelpObjects2= [];
gdjs.BootCode.GDExitObjects1= [];
gdjs.BootCode.GDExitObjects2= [];
gdjs.BootCode.GDLoad2Objects1= [];
gdjs.BootCode.GDLoad2Objects2= [];
gdjs.BootCode.GDE_9595KeysObjects1= [];
gdjs.BootCode.GDE_9595KeysObjects2= [];
gdjs.BootCode.GDOw_9595AhhObjects1= [];
gdjs.BootCode.GDOw_9595AhhObjects2= [];
gdjs.BootCode.GDBlank_9595wallsObjects1= [];
gdjs.BootCode.GDBlank_9595wallsObjects2= [];
gdjs.BootCode.GDHit_9595boxObjects1= [];
gdjs.BootCode.GDHit_9595boxObjects2= [];
gdjs.BootCode.GDOverlayObjects1= [];
gdjs.BootCode.GDOverlayObjects2= [];
gdjs.BootCode.GDWelcomeObjects1= [];
gdjs.BootCode.GDWelcomeObjects2= [];
gdjs.BootCode.GDDissmissObjects1= [];
gdjs.BootCode.GDDissmissObjects2= [];
gdjs.BootCode.GDWhats_9595new_9595textObjects1= [];
gdjs.BootCode.GDWhats_9595new_9595textObjects2= [];
gdjs.BootCode.GDupdatesObjects1= [];
gdjs.BootCode.GDupdatesObjects2= [];
gdjs.BootCode.GDbox_9595helpObjects1= [];
gdjs.BootCode.GDbox_9595helpObjects2= [];
gdjs.BootCode.GDtitleObjects1= [];
gdjs.BootCode.GDtitleObjects2= [];
gdjs.BootCode.GDbodypageObjects1= [];
gdjs.BootCode.GDbodypageObjects2= [];
gdjs.BootCode.GDDissmiss2Objects1= [];
gdjs.BootCode.GDDissmiss2Objects2= [];
gdjs.BootCode.GDinfoObjects1= [];
gdjs.BootCode.GDinfoObjects2= [];
gdjs.BootCode.GDNewTextObjects1= [];
gdjs.BootCode.GDNewTextObjects2= [];
gdjs.BootCode.GDGlobal_9595PlayObjects1= [];
gdjs.BootCode.GDGlobal_9595PlayObjects2= [];
gdjs.BootCode.GDGlobal_9595EditorObjects1= [];
gdjs.BootCode.GDGlobal_9595EditorObjects2= [];
gdjs.BootCode.GDGlobal_9595HomeObjects1= [];
gdjs.BootCode.GDGlobal_9595HomeObjects2= [];
gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1= [];
gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects2= [];
gdjs.BootCode.GDGlobal_9595Blank_9595KnobObjects1= [];
gdjs.BootCode.GDGlobal_9595Blank_9595KnobObjects2= [];
gdjs.BootCode.GDGlobal_9595BaseObjects1= [];
gdjs.BootCode.GDGlobal_9595BaseObjects2= [];
gdjs.BootCode.GDGlobal_9595Top_9595LiteObjects1= [];
gdjs.BootCode.GDGlobal_9595Top_9595LiteObjects2= [];
gdjs.BootCode.GDAutoPlayObjects1= [];
gdjs.BootCode.GDAutoPlayObjects2= [];
gdjs.BootCode.GDLoading_9595alertObjects1= [];
gdjs.BootCode.GDLoading_9595alertObjects2= [];
gdjs.BootCode.GDTri_9595Blank_9595Objects1= [];
gdjs.BootCode.GDTri_9595Blank_9595Objects2= [];
gdjs.BootCode.GDSnapShotObjects1= [];
gdjs.BootCode.GDSnapShotObjects2= [];
gdjs.BootCode.GDBackgroundObjects1= [];
gdjs.BootCode.GDBackgroundObjects2= [];
gdjs.BootCode.GDfadeObjects1= [];
gdjs.BootCode.GDfadeObjects2= [];


gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDGlobal_95959595EditorObjects1Objects = Hashtable.newFrom({"Global_Editor": gdjs.BootCode.GDGlobal_9595EditorObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDLoadObjects1Objects = Hashtable.newFrom({"Load": gdjs.BootCode.GDLoadObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDLoadObjects1Objects = Hashtable.newFrom({"Load": gdjs.BootCode.GDLoadObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDEditorObjects1Objects = Hashtable.newFrom({"Editor": gdjs.BootCode.GDEditorObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDEditorObjects1Objects = Hashtable.newFrom({"Editor": gdjs.BootCode.GDEditorObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.BootCode.GDExitObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDShareObjects1Objects = Hashtable.newFrom({"Share": gdjs.BootCode.GDShareObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDCreditsObjects1Objects = Hashtable.newFrom({"Credits": gdjs.BootCode.GDCreditsObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDGlobal_95959595HomeObjects1Objects = Hashtable.newFrom({"Global_Home": gdjs.BootCode.GDGlobal_9595HomeObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDEditorObjects1Objects = Hashtable.newFrom({"Editor": gdjs.BootCode.GDEditorObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDEditorObjects1Objects = Hashtable.newFrom({"Editor": gdjs.BootCode.GDEditorObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDLoadObjects1Objects = Hashtable.newFrom({"Load": gdjs.BootCode.GDLoadObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDShareObjects1Objects = Hashtable.newFrom({"Share": gdjs.BootCode.GDShareObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDCreditsObjects1Objects = Hashtable.newFrom({"Credits": gdjs.BootCode.GDCreditsObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDHelpObjects1Objects = Hashtable.newFrom({"Help": gdjs.BootCode.GDHelpObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.BootCode.GDExitObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDinfoObjects1Objects = Hashtable.newFrom({"info": gdjs.BootCode.GDinfoObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDinfoObjects1Objects = Hashtable.newFrom({"info": gdjs.BootCode.GDinfoObjects1});
gdjs.BootCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDinfoObjects1Objects = Hashtable.newFrom({"info": gdjs.BootCode.GDinfoObjects1});
gdjs.BootCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDGlobal_95959595HomeObjects1Objects = Hashtable.newFrom({"Global_Home": gdjs.BootCode.GDGlobal_9595HomeObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDGlobal_95959595HomeObjects1Objects = Hashtable.newFrom({"Global_Home": gdjs.BootCode.GDGlobal_9595HomeObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDGlobal_95959595PlayObjects1Objects = Hashtable.newFrom({"Global_Play": gdjs.BootCode.GDGlobal_9595PlayObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDGlobal_95959595EditorObjects1Objects = Hashtable.newFrom({"Global_Editor": gdjs.BootCode.GDGlobal_9595EditorObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDHelpObjects1Objects = Hashtable.newFrom({"Help": gdjs.BootCode.GDHelpObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDTri_95959595Blank_95959595Objects1Objects = Hashtable.newFrom({"Tri_Blank_": gdjs.BootCode.GDTri_9595Blank_9595Objects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDGlobal_95959595BaseObjects1Objects = Hashtable.newFrom({"Global_Base": gdjs.BootCode.GDGlobal_9595BaseObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDDissmissObjects1Objects = Hashtable.newFrom({"Dissmiss": gdjs.BootCode.GDDissmissObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDDissmiss2Objects1Objects = Hashtable.newFrom({"Dissmiss2": gdjs.BootCode.GDDissmiss2Objects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDDissmiss2Objects1Objects = Hashtable.newFrom({"Dissmiss2": gdjs.BootCode.GDDissmiss2Objects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDDissmissObjects1Objects = Hashtable.newFrom({"Dissmiss": gdjs.BootCode.GDDissmissObjects1});
gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDDissmissObjects1Objects = Hashtable.newFrom({"Dissmiss": gdjs.BootCode.GDDissmissObjects1});
gdjs.BootCode.eventsList2 = function(runtimeScene) {

{

/* Reuse gdjs.BootCode.GDDissmissObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDDissmissObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).getChild("hasbeenused").setNumber(1);
}{runtimeScene.getGame().getVariables().getFromIndex(2).getChild("version number").setNumber(51);
}}

}


};gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDDissmiss2Objects1Objects = Hashtable.newFrom({"Dissmiss2": gdjs.BootCode.GDDissmiss2Objects1});
gdjs.BootCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loading_alert"), gdjs.BootCode.GDLoading_9595alertObjects1);
gdjs.copyArray(runtimeScene.getObjects("Whats_new_text"), gdjs.BootCode.GDWhats_9595new_9595textObjects1);
{gdjs.evtTools.runtimeScene.prioritizeLoadingOfScene(runtimeScene, "Load");
}{for(var i = 0, len = gdjs.BootCode.GDLoading_9595alertObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDLoading_9595alertObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{gdjs.evtTools.window.setWindowTitle(runtimeScene, "The Crave Patch Project");
}{gdjs.evtsExt__AuthorizedPlatformsValidation__AddExecution.func(runtimeScene, "gd.games", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "b");
}{for(var i = 0, len = gdjs.BootCode.GDLoading_9595alertObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDLoading_9595alertObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "Help");
}{for(var i = 0, len = gdjs.BootCode.GDWhats_9595new_9595textObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDWhats_9595new_9595textObjects1[i].setBBText("[b][size=30]What's new in version ");
}
}{for(var i = 0, len = gdjs.BootCode.GDWhats_9595new_9595textObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDWhats_9595new_9595textObjects1[i].setBBText(gdjs.BootCode.GDWhats_9595new_9595textObjects1[i].getBBText() + (gdjs.evtsExt__GetPropertiesData__ReturnGameVersion.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Editor"), gdjs.BootCode.GDGlobal_9595EditorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDGlobal_95959595EditorObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Editor");
}}

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Load"), gdjs.BootCode.GDLoadObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDLoadObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Pre");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Load"), gdjs.BootCode.GDLoadObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDLoadObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getSceneLoadingProgress(runtimeScene, "Load") < 100;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loading_alert"), gdjs.BootCode.GDLoading_9595alertObjects1);
{for(var i = 0, len = gdjs.BootCode.GDLoading_9595alertObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDLoading_9595alertObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
}{for(var i = 0, len = gdjs.BootCode.GDLoading_9595alertObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDLoading_9595alertObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}{gdjs.evtTools.window.setWindowTitle(runtimeScene, "Loading");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Editor"), gdjs.BootCode.GDEditorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDEditorObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Editor");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Editor"), gdjs.BootCode.GDEditorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDEditorObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getSceneLoadingProgress(runtimeScene, "Editor") < 100;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Loading_alert"), gdjs.BootCode.GDLoading_9595alertObjects1);
{for(var i = 0, len = gdjs.BootCode.GDLoading_9595alertObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDLoading_9595alertObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
}{gdjs.evtTools.window.setWindowTitle(runtimeScene, "Loading");
}{for(var i = 0, len = gdjs.BootCode.GDLoading_9595alertObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDLoading_9595alertObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.BootCode.GDExitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDExitObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Share"), gdjs.BootCode.GDShareObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDShareObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtsExt__Clipboard__WriteText.func(runtimeScene, "https://github.com/Connor-ed/The-Crave-Patch-Project", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__PopUp__Alert.func(runtimeScene, "Copied to Clipboard", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Credits"), gdjs.BootCode.GDCreditsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDCreditsObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://github.com/Connor-ed/The-Crave-Patch-Project/blob/main/CREDITS.md", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Home"), gdjs.BootCode.GDGlobal_9595HomeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDGlobal_95959595HomeObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Boot", false);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
}
if (isConditionTrue_0) {
{gdjs.evtsExt__PopUp__Alert.func(runtimeScene, "Mobile devices are not supported at this time", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Boot");
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("M_TEXT"), gdjs.BootCode.GDM_9595TEXTObjects1);
{gdjs.evtTools.runtimeScene.prioritizeLoadingOfScene(runtimeScene, "Editor");
}{for(var i = 0, len = gdjs.BootCode.GDM_9595TEXTObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDM_9595TEXTObjects1[i].getBehavior("Animation").setAnimationName("Blank");
}
}{gdjs.evtTools.runtimeScene.prioritizeLoadingOfScene(runtimeScene, "Load");
}}

}


{



}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Editor"), gdjs.BootCode.GDEditorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDEditorObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("M_TEXT"), gdjs.BootCode.GDM_9595TEXTObjects1);
{for(var i = 0, len = gdjs.BootCode.GDM_9595TEXTObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDM_9595TEXTObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Editor"), gdjs.BootCode.GDEditorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDEditorObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("M_TEXT"), gdjs.BootCode.GDM_9595TEXTObjects1);
{for(var i = 0, len = gdjs.BootCode.GDM_9595TEXTObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDM_9595TEXTObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Load"), gdjs.BootCode.GDLoadObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDLoadObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("M_TEXT"), gdjs.BootCode.GDM_9595TEXTObjects1);
{for(var i = 0, len = gdjs.BootCode.GDM_9595TEXTObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDM_9595TEXTObjects1[i].getBehavior("Animation").setAnimationIndex(2);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Share"), gdjs.BootCode.GDShareObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDShareObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("M_TEXT"), gdjs.BootCode.GDM_9595TEXTObjects1);
{for(var i = 0, len = gdjs.BootCode.GDM_9595TEXTObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDM_9595TEXTObjects1[i].getBehavior("Animation").setAnimationIndex(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Credits"), gdjs.BootCode.GDCreditsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDCreditsObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("M_TEXT"), gdjs.BootCode.GDM_9595TEXTObjects1);
{for(var i = 0, len = gdjs.BootCode.GDM_9595TEXTObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDM_9595TEXTObjects1[i].getBehavior("Animation").setAnimationIndex(4);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Help"), gdjs.BootCode.GDHelpObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDHelpObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("M_TEXT"), gdjs.BootCode.GDM_9595TEXTObjects1);
{for(var i = 0, len = gdjs.BootCode.GDM_9595TEXTObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDM_9595TEXTObjects1[i].getBehavior("Animation").setAnimationIndex(5);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.BootCode.GDExitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDExitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("M_TEXT"), gdjs.BootCode.GDM_9595TEXTObjects1);
{for(var i = 0, len = gdjs.BootCode.GDM_9595TEXTObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDM_9595TEXTObjects1[i].getBehavior("Animation").setAnimationIndex(6);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("info"), gdjs.BootCode.GDinfoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDinfoObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.BootCode.GDinfoObjects1 */
{for(var i = 0, len = gdjs.BootCode.GDinfoObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDinfoObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("info"), gdjs.BootCode.GDinfoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDinfoObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.BootCode.GDinfoObjects1 */
{for(var i = 0, len = gdjs.BootCode.GDinfoObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDinfoObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
}
{ //Subevents
gdjs.BootCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("info"), gdjs.BootCode.GDinfoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDinfoObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).getChild("hasbeenused").setNumber(0);
}
{ //Subevents
gdjs.BootCode.eventsList1(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Home"), gdjs.BootCode.GDGlobal_9595HomeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDGlobal_95959595HomeObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1);
{for(var i = 0, len = gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Home"), gdjs.BootCode.GDGlobal_9595HomeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDGlobal_95959595HomeObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1);
{for(var i = 0, len = gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Play"), gdjs.BootCode.GDGlobal_9595PlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDGlobal_95959595PlayObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1);
{for(var i = 0, len = gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1[i].getBehavior("Animation").setAnimationIndex(2);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Editor"), gdjs.BootCode.GDGlobal_9595EditorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDGlobal_95959595EditorObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1);
{for(var i = 0, len = gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1[i].getBehavior("Animation").setAnimationIndex(3);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Help"), gdjs.BootCode.GDHelpObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDHelpObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "Help");
}}

}


{



}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Tri_Blank_"), gdjs.BootCode.GDTri_9595Blank_9595Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasDoubleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDTri_95959595Blank_95959595Objects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Base"), gdjs.BootCode.GDGlobal_9595BaseObjects1);
{gdjs.evtsExt__UploadDownloadImageFile__UploadImageFile.func(runtimeScene, gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDGlobal_95959595BaseObjects1Objects, true, gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Boot");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Dissmiss"), gdjs.BootCode.GDDissmissObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDDissmissObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Welcome"), gdjs.BootCode.GDWelcomeObjects1);
{for(var i = 0, len = gdjs.BootCode.GDWelcomeObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDWelcomeObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dissmiss2"), gdjs.BootCode.GDDissmiss2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDDissmiss2Objects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("box_help"), gdjs.BootCode.GDbox_9595helpObjects1);
{for(var i = 0, len = gdjs.BootCode.GDbox_9595helpObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDbox_9595helpObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dissmiss2"), gdjs.BootCode.GDDissmiss2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDDissmiss2Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("box_help"), gdjs.BootCode.GDbox_9595helpObjects1);
{for(var i = 0, len = gdjs.BootCode.GDbox_9595helpObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDbox_9595helpObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dissmiss"), gdjs.BootCode.GDDissmissObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDDissmissObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Welcome"), gdjs.BootCode.GDWelcomeObjects1);
{for(var i = 0, len = gdjs.BootCode.GDWelcomeObjects1.length ;i < len;++i) {
    gdjs.BootCode.GDWelcomeObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
}
{ //Subevents
gdjs.BootCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dissmiss2"), gdjs.BootCode.GDDissmiss2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDDissmiss2Objects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Help");
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getChild("hasbeenused").getAsNumber() == 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "welcome");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getChild("hasbeenused").getAsNumber() == 1);
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "welcome");
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
}

}


};

gdjs.BootCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.BootCode.GDVersion_9595detailsObjects1.length = 0;
gdjs.BootCode.GDVersion_9595detailsObjects2.length = 0;
gdjs.BootCode.GDEditorObjects1.length = 0;
gdjs.BootCode.GDEditorObjects2.length = 0;
gdjs.BootCode.GDM_9595TEXTObjects1.length = 0;
gdjs.BootCode.GDM_9595TEXTObjects2.length = 0;
gdjs.BootCode.GDShareObjects1.length = 0;
gdjs.BootCode.GDShareObjects2.length = 0;
gdjs.BootCode.GDLoadObjects1.length = 0;
gdjs.BootCode.GDLoadObjects2.length = 0;
gdjs.BootCode.GDCreditsObjects1.length = 0;
gdjs.BootCode.GDCreditsObjects2.length = 0;
gdjs.BootCode.GDHelpObjects1.length = 0;
gdjs.BootCode.GDHelpObjects2.length = 0;
gdjs.BootCode.GDExitObjects1.length = 0;
gdjs.BootCode.GDExitObjects2.length = 0;
gdjs.BootCode.GDLoad2Objects1.length = 0;
gdjs.BootCode.GDLoad2Objects2.length = 0;
gdjs.BootCode.GDE_9595KeysObjects1.length = 0;
gdjs.BootCode.GDE_9595KeysObjects2.length = 0;
gdjs.BootCode.GDOw_9595AhhObjects1.length = 0;
gdjs.BootCode.GDOw_9595AhhObjects2.length = 0;
gdjs.BootCode.GDBlank_9595wallsObjects1.length = 0;
gdjs.BootCode.GDBlank_9595wallsObjects2.length = 0;
gdjs.BootCode.GDHit_9595boxObjects1.length = 0;
gdjs.BootCode.GDHit_9595boxObjects2.length = 0;
gdjs.BootCode.GDOverlayObjects1.length = 0;
gdjs.BootCode.GDOverlayObjects2.length = 0;
gdjs.BootCode.GDWelcomeObjects1.length = 0;
gdjs.BootCode.GDWelcomeObjects2.length = 0;
gdjs.BootCode.GDDissmissObjects1.length = 0;
gdjs.BootCode.GDDissmissObjects2.length = 0;
gdjs.BootCode.GDWhats_9595new_9595textObjects1.length = 0;
gdjs.BootCode.GDWhats_9595new_9595textObjects2.length = 0;
gdjs.BootCode.GDupdatesObjects1.length = 0;
gdjs.BootCode.GDupdatesObjects2.length = 0;
gdjs.BootCode.GDbox_9595helpObjects1.length = 0;
gdjs.BootCode.GDbox_9595helpObjects2.length = 0;
gdjs.BootCode.GDtitleObjects1.length = 0;
gdjs.BootCode.GDtitleObjects2.length = 0;
gdjs.BootCode.GDbodypageObjects1.length = 0;
gdjs.BootCode.GDbodypageObjects2.length = 0;
gdjs.BootCode.GDDissmiss2Objects1.length = 0;
gdjs.BootCode.GDDissmiss2Objects2.length = 0;
gdjs.BootCode.GDinfoObjects1.length = 0;
gdjs.BootCode.GDinfoObjects2.length = 0;
gdjs.BootCode.GDNewTextObjects1.length = 0;
gdjs.BootCode.GDNewTextObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595PlayObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595PlayObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595EditorObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595EditorObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595HomeObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595HomeObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595Blank_9595KnobObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595Blank_9595KnobObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595BaseObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595BaseObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595Top_9595LiteObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595Top_9595LiteObjects2.length = 0;
gdjs.BootCode.GDAutoPlayObjects1.length = 0;
gdjs.BootCode.GDAutoPlayObjects2.length = 0;
gdjs.BootCode.GDLoading_9595alertObjects1.length = 0;
gdjs.BootCode.GDLoading_9595alertObjects2.length = 0;
gdjs.BootCode.GDTri_9595Blank_9595Objects1.length = 0;
gdjs.BootCode.GDTri_9595Blank_9595Objects2.length = 0;
gdjs.BootCode.GDSnapShotObjects1.length = 0;
gdjs.BootCode.GDSnapShotObjects2.length = 0;
gdjs.BootCode.GDBackgroundObjects1.length = 0;
gdjs.BootCode.GDBackgroundObjects2.length = 0;
gdjs.BootCode.GDfadeObjects1.length = 0;
gdjs.BootCode.GDfadeObjects2.length = 0;

gdjs.BootCode.eventsList3(runtimeScene);
gdjs.BootCode.GDVersion_9595detailsObjects1.length = 0;
gdjs.BootCode.GDVersion_9595detailsObjects2.length = 0;
gdjs.BootCode.GDEditorObjects1.length = 0;
gdjs.BootCode.GDEditorObjects2.length = 0;
gdjs.BootCode.GDM_9595TEXTObjects1.length = 0;
gdjs.BootCode.GDM_9595TEXTObjects2.length = 0;
gdjs.BootCode.GDShareObjects1.length = 0;
gdjs.BootCode.GDShareObjects2.length = 0;
gdjs.BootCode.GDLoadObjects1.length = 0;
gdjs.BootCode.GDLoadObjects2.length = 0;
gdjs.BootCode.GDCreditsObjects1.length = 0;
gdjs.BootCode.GDCreditsObjects2.length = 0;
gdjs.BootCode.GDHelpObjects1.length = 0;
gdjs.BootCode.GDHelpObjects2.length = 0;
gdjs.BootCode.GDExitObjects1.length = 0;
gdjs.BootCode.GDExitObjects2.length = 0;
gdjs.BootCode.GDLoad2Objects1.length = 0;
gdjs.BootCode.GDLoad2Objects2.length = 0;
gdjs.BootCode.GDE_9595KeysObjects1.length = 0;
gdjs.BootCode.GDE_9595KeysObjects2.length = 0;
gdjs.BootCode.GDOw_9595AhhObjects1.length = 0;
gdjs.BootCode.GDOw_9595AhhObjects2.length = 0;
gdjs.BootCode.GDBlank_9595wallsObjects1.length = 0;
gdjs.BootCode.GDBlank_9595wallsObjects2.length = 0;
gdjs.BootCode.GDHit_9595boxObjects1.length = 0;
gdjs.BootCode.GDHit_9595boxObjects2.length = 0;
gdjs.BootCode.GDOverlayObjects1.length = 0;
gdjs.BootCode.GDOverlayObjects2.length = 0;
gdjs.BootCode.GDWelcomeObjects1.length = 0;
gdjs.BootCode.GDWelcomeObjects2.length = 0;
gdjs.BootCode.GDDissmissObjects1.length = 0;
gdjs.BootCode.GDDissmissObjects2.length = 0;
gdjs.BootCode.GDWhats_9595new_9595textObjects1.length = 0;
gdjs.BootCode.GDWhats_9595new_9595textObjects2.length = 0;
gdjs.BootCode.GDupdatesObjects1.length = 0;
gdjs.BootCode.GDupdatesObjects2.length = 0;
gdjs.BootCode.GDbox_9595helpObjects1.length = 0;
gdjs.BootCode.GDbox_9595helpObjects2.length = 0;
gdjs.BootCode.GDtitleObjects1.length = 0;
gdjs.BootCode.GDtitleObjects2.length = 0;
gdjs.BootCode.GDbodypageObjects1.length = 0;
gdjs.BootCode.GDbodypageObjects2.length = 0;
gdjs.BootCode.GDDissmiss2Objects1.length = 0;
gdjs.BootCode.GDDissmiss2Objects2.length = 0;
gdjs.BootCode.GDinfoObjects1.length = 0;
gdjs.BootCode.GDinfoObjects2.length = 0;
gdjs.BootCode.GDNewTextObjects1.length = 0;
gdjs.BootCode.GDNewTextObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595PlayObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595PlayObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595EditorObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595EditorObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595HomeObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595HomeObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595Top_9595MenuObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595Blank_9595KnobObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595Blank_9595KnobObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595BaseObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595BaseObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595Top_9595LiteObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595Top_9595LiteObjects2.length = 0;
gdjs.BootCode.GDAutoPlayObjects1.length = 0;
gdjs.BootCode.GDAutoPlayObjects2.length = 0;
gdjs.BootCode.GDLoading_9595alertObjects1.length = 0;
gdjs.BootCode.GDLoading_9595alertObjects2.length = 0;
gdjs.BootCode.GDTri_9595Blank_9595Objects1.length = 0;
gdjs.BootCode.GDTri_9595Blank_9595Objects2.length = 0;
gdjs.BootCode.GDSnapShotObjects1.length = 0;
gdjs.BootCode.GDSnapShotObjects2.length = 0;
gdjs.BootCode.GDBackgroundObjects1.length = 0;
gdjs.BootCode.GDBackgroundObjects2.length = 0;
gdjs.BootCode.GDfadeObjects1.length = 0;
gdjs.BootCode.GDfadeObjects2.length = 0;


return;

}

gdjs['BootCode'] = gdjs.BootCode;
