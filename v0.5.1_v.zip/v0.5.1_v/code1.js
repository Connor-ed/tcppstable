gdjs.EditorCode = {};
gdjs.EditorCode.localVariables = [];
gdjs.EditorCode.GDKnobObjects1= [];
gdjs.EditorCode.GDKnobObjects2= [];
gdjs.EditorCode.GDEdit_9595ToggleObjects1= [];
gdjs.EditorCode.GDEdit_9595ToggleObjects2= [];
gdjs.EditorCode.GDInstuctionsObjects1= [];
gdjs.EditorCode.GDInstuctionsObjects2= [];
gdjs.EditorCode.GDDetail_9595modeObjects1= [];
gdjs.EditorCode.GDDetail_9595modeObjects2= [];
gdjs.EditorCode.GDSnapShot_9595textObjects1= [];
gdjs.EditorCode.GDSnapShot_9595textObjects2= [];
gdjs.EditorCode.GDDetail_9595overlayObjects1= [];
gdjs.EditorCode.GDDetail_9595overlayObjects2= [];
gdjs.EditorCode.GDNameObjects1= [];
gdjs.EditorCode.GDNameObjects2= [];
gdjs.EditorCode.GDTextToImgObjects1= [];
gdjs.EditorCode.GDTextToImgObjects2= [];
gdjs.EditorCode.GDGlobal_9595PlayObjects1= [];
gdjs.EditorCode.GDGlobal_9595PlayObjects2= [];
gdjs.EditorCode.GDGlobal_9595EditorObjects1= [];
gdjs.EditorCode.GDGlobal_9595EditorObjects2= [];
gdjs.EditorCode.GDGlobal_9595HomeObjects1= [];
gdjs.EditorCode.GDGlobal_9595HomeObjects2= [];
gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1= [];
gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects2= [];
gdjs.EditorCode.GDGlobal_9595Blank_9595KnobObjects1= [];
gdjs.EditorCode.GDGlobal_9595Blank_9595KnobObjects2= [];
gdjs.EditorCode.GDGlobal_9595BaseObjects1= [];
gdjs.EditorCode.GDGlobal_9595BaseObjects2= [];
gdjs.EditorCode.GDGlobal_9595Top_9595LiteObjects1= [];
gdjs.EditorCode.GDGlobal_9595Top_9595LiteObjects2= [];
gdjs.EditorCode.GDAutoPlayObjects1= [];
gdjs.EditorCode.GDAutoPlayObjects2= [];
gdjs.EditorCode.GDLoading_9595alertObjects1= [];
gdjs.EditorCode.GDLoading_9595alertObjects2= [];
gdjs.EditorCode.GDTri_9595Blank_9595Objects1= [];
gdjs.EditorCode.GDTri_9595Blank_9595Objects2= [];
gdjs.EditorCode.GDSnapShotObjects1= [];
gdjs.EditorCode.GDSnapShotObjects2= [];
gdjs.EditorCode.GDBackgroundObjects1= [];
gdjs.EditorCode.GDBackgroundObjects2= [];
gdjs.EditorCode.GDfadeObjects1= [];
gdjs.EditorCode.GDfadeObjects2= [];


gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDKnobObjects1Objects = Hashtable.newFrom({"Knob": gdjs.EditorCode.GDKnobObjects1});
gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDKnobObjects1Objects = Hashtable.newFrom({"Knob": gdjs.EditorCode.GDKnobObjects1});
gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDKnobObjects1Objects = Hashtable.newFrom({"Knob": gdjs.EditorCode.GDKnobObjects1});
gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDGlobal_95959595EditorObjects1Objects = Hashtable.newFrom({"Global_Editor": gdjs.EditorCode.GDGlobal_9595EditorObjects1});
gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDGlobal_95959595HomeObjects1Objects = Hashtable.newFrom({"Global_Home": gdjs.EditorCode.GDGlobal_9595HomeObjects1});
gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDGlobal_95959595HomeObjects1Objects = Hashtable.newFrom({"Global_Home": gdjs.EditorCode.GDGlobal_9595HomeObjects1});
gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDGlobal_95959595HomeObjects1Objects = Hashtable.newFrom({"Global_Home": gdjs.EditorCode.GDGlobal_9595HomeObjects1});
gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDGlobal_95959595PlayObjects1Objects = Hashtable.newFrom({"Global_Play": gdjs.EditorCode.GDGlobal_9595PlayObjects1});
gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDGlobal_95959595EditorObjects1Objects = Hashtable.newFrom({"Global_Editor": gdjs.EditorCode.GDGlobal_9595EditorObjects1});
gdjs.EditorCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.EditorCode.GDNameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EditorCode.GDNameObjects1.length;i<l;++i) {
    if ( gdjs.EditorCode.GDNameObjects1[i].getBehavior("Text").getText() != "" ) {
        isConditionTrue_0 = true;
        gdjs.EditorCode.GDNameObjects1[k] = gdjs.EditorCode.GDNameObjects1[i];
        ++k;
    }
}
gdjs.EditorCode.GDNameObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Instuctions"), gdjs.EditorCode.GDInstuctionsObjects1);
/* Reuse gdjs.EditorCode.GDNameObjects1 */
gdjs.copyArray(runtimeScene.getObjects("TextToImg"), gdjs.EditorCode.GDTextToImgObjects1);
{for(var i = 0, len = gdjs.EditorCode.GDTextToImgObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDTextToImgObjects1[i].getBehavior("Text").setText((( gdjs.EditorCode.GDInstuctionsObjects1.length === 0 ) ? "" :gdjs.EditorCode.GDInstuctionsObjects1[0].getBehavior("Text").getText()));
}
}{gdjs.screenshot.takeScreenshot(runtimeScene, gdjs.fileSystem.getDesktopPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + (( gdjs.EditorCode.GDNameObjects1.length === 0 ) ? "" :gdjs.EditorCode.GDNameObjects1[0].getBehavior("Text").getText()) + ".Patch.png");
}}

}


};gdjs.EditorCode.eventsList1 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.window.setWindowTitle(runtimeScene, "The Crave Patch Project");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Knob"), gdjs.EditorCode.GDKnobObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDKnobObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.EditorCode.GDKnobObjects1 */
{for(var i = 0, len = gdjs.EditorCode.GDKnobObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDKnobObjects1[i].rotate(30, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Knob"), gdjs.EditorCode.GDKnobObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDKnobObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.EditorCode.GDKnobObjects1 */
{for(var i = 0, len = gdjs.EditorCode.GDKnobObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDKnobObjects1[i].rotate(-(30), runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Knob"), gdjs.EditorCode.GDKnobObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDKnobObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasDoubleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.EditorCode.GDKnobObjects1 */
{for(var i = 0, len = gdjs.EditorCode.GDKnobObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDKnobObjects1[i].rotateTowardAngle(0, 0, runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Editor"), gdjs.EditorCode.GDGlobal_9595EditorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDGlobal_95959595EditorObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Editor");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Home"), gdjs.EditorCode.GDGlobal_9595HomeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDGlobal_95959595HomeObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Boot");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Detail_mode"), gdjs.EditorCode.GDDetail_9595modeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EditorCode.GDDetail_9595modeObjects1.length;i<l;++i) {
    if ( gdjs.EditorCode.GDDetail_9595modeObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EditorCode.GDDetail_9595modeObjects1[k] = gdjs.EditorCode.GDDetail_9595modeObjects1[i];
        ++k;
    }
}
gdjs.EditorCode.GDDetail_9595modeObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Lite"), gdjs.EditorCode.GDGlobal_9595Top_9595LiteObjects1);
{for(var i = 0, len = gdjs.EditorCode.GDGlobal_9595Top_9595LiteObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDGlobal_9595Top_9595LiteObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Detail_mode"), gdjs.EditorCode.GDDetail_9595modeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EditorCode.GDDetail_9595modeObjects1.length;i<l;++i) {
    if ( !(gdjs.EditorCode.GDDetail_9595modeObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.EditorCode.GDDetail_9595modeObjects1[k] = gdjs.EditorCode.GDDetail_9595modeObjects1[i];
        ++k;
    }
}
gdjs.EditorCode.GDDetail_9595modeObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Lite"), gdjs.EditorCode.GDGlobal_9595Top_9595LiteObjects1);
{for(var i = 0, len = gdjs.EditorCode.GDGlobal_9595Top_9595LiteObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDGlobal_9595Top_9595LiteObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Home"), gdjs.EditorCode.GDGlobal_9595HomeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDGlobal_95959595HomeObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1);
{for(var i = 0, len = gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Home"), gdjs.EditorCode.GDGlobal_9595HomeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDGlobal_95959595HomeObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1);
{for(var i = 0, len = gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Play"), gdjs.EditorCode.GDGlobal_9595PlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDGlobal_95959595PlayObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1);
{for(var i = 0, len = gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1[i].getBehavior("Animation").setAnimationIndex(2);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Editor"), gdjs.EditorCode.GDGlobal_9595EditorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDGlobal_95959595EditorObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1);
{for(var i = 0, len = gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1[i].getBehavior("Animation").setAnimationIndex(3);
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.EditorCode.GDNameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LSystem");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EditorCode.GDNameObjects1.length;i<l;++i) {
    if ( gdjs.EditorCode.GDNameObjects1[i].getBehavior("Text").getText() == "" ) {
        isConditionTrue_0 = true;
        gdjs.EditorCode.GDNameObjects1[k] = gdjs.EditorCode.GDNameObjects1[i];
        ++k;
    }
}
gdjs.EditorCode.GDNameObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.EditorCode.GDNameObjects1 */
{for(var i = 0, len = gdjs.EditorCode.GDNameObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDNameObjects1[i].getBehavior("Flash").Flash(0.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LSystem");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.EditorCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "LSystem");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}
if (isConditionTrue_0) {
}

}


{



}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.EditorCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.EditorCode.GDKnobObjects1.length = 0;
gdjs.EditorCode.GDKnobObjects2.length = 0;
gdjs.EditorCode.GDEdit_9595ToggleObjects1.length = 0;
gdjs.EditorCode.GDEdit_9595ToggleObjects2.length = 0;
gdjs.EditorCode.GDInstuctionsObjects1.length = 0;
gdjs.EditorCode.GDInstuctionsObjects2.length = 0;
gdjs.EditorCode.GDDetail_9595modeObjects1.length = 0;
gdjs.EditorCode.GDDetail_9595modeObjects2.length = 0;
gdjs.EditorCode.GDSnapShot_9595textObjects1.length = 0;
gdjs.EditorCode.GDSnapShot_9595textObjects2.length = 0;
gdjs.EditorCode.GDDetail_9595overlayObjects1.length = 0;
gdjs.EditorCode.GDDetail_9595overlayObjects2.length = 0;
gdjs.EditorCode.GDNameObjects1.length = 0;
gdjs.EditorCode.GDNameObjects2.length = 0;
gdjs.EditorCode.GDTextToImgObjects1.length = 0;
gdjs.EditorCode.GDTextToImgObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595PlayObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595PlayObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595EditorObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595EditorObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595HomeObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595HomeObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595Blank_9595KnobObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595Blank_9595KnobObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595BaseObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595BaseObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595Top_9595LiteObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595Top_9595LiteObjects2.length = 0;
gdjs.EditorCode.GDAutoPlayObjects1.length = 0;
gdjs.EditorCode.GDAutoPlayObjects2.length = 0;
gdjs.EditorCode.GDLoading_9595alertObjects1.length = 0;
gdjs.EditorCode.GDLoading_9595alertObjects2.length = 0;
gdjs.EditorCode.GDTri_9595Blank_9595Objects1.length = 0;
gdjs.EditorCode.GDTri_9595Blank_9595Objects2.length = 0;
gdjs.EditorCode.GDSnapShotObjects1.length = 0;
gdjs.EditorCode.GDSnapShotObjects2.length = 0;
gdjs.EditorCode.GDBackgroundObjects1.length = 0;
gdjs.EditorCode.GDBackgroundObjects2.length = 0;
gdjs.EditorCode.GDfadeObjects1.length = 0;
gdjs.EditorCode.GDfadeObjects2.length = 0;

gdjs.EditorCode.eventsList1(runtimeScene);
gdjs.EditorCode.GDKnobObjects1.length = 0;
gdjs.EditorCode.GDKnobObjects2.length = 0;
gdjs.EditorCode.GDEdit_9595ToggleObjects1.length = 0;
gdjs.EditorCode.GDEdit_9595ToggleObjects2.length = 0;
gdjs.EditorCode.GDInstuctionsObjects1.length = 0;
gdjs.EditorCode.GDInstuctionsObjects2.length = 0;
gdjs.EditorCode.GDDetail_9595modeObjects1.length = 0;
gdjs.EditorCode.GDDetail_9595modeObjects2.length = 0;
gdjs.EditorCode.GDSnapShot_9595textObjects1.length = 0;
gdjs.EditorCode.GDSnapShot_9595textObjects2.length = 0;
gdjs.EditorCode.GDDetail_9595overlayObjects1.length = 0;
gdjs.EditorCode.GDDetail_9595overlayObjects2.length = 0;
gdjs.EditorCode.GDNameObjects1.length = 0;
gdjs.EditorCode.GDNameObjects2.length = 0;
gdjs.EditorCode.GDTextToImgObjects1.length = 0;
gdjs.EditorCode.GDTextToImgObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595PlayObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595PlayObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595EditorObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595EditorObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595HomeObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595HomeObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595Top_9595MenuObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595Blank_9595KnobObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595Blank_9595KnobObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595BaseObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595BaseObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595Top_9595LiteObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595Top_9595LiteObjects2.length = 0;
gdjs.EditorCode.GDAutoPlayObjects1.length = 0;
gdjs.EditorCode.GDAutoPlayObjects2.length = 0;
gdjs.EditorCode.GDLoading_9595alertObjects1.length = 0;
gdjs.EditorCode.GDLoading_9595alertObjects2.length = 0;
gdjs.EditorCode.GDTri_9595Blank_9595Objects1.length = 0;
gdjs.EditorCode.GDTri_9595Blank_9595Objects2.length = 0;
gdjs.EditorCode.GDSnapShotObjects1.length = 0;
gdjs.EditorCode.GDSnapShotObjects2.length = 0;
gdjs.EditorCode.GDBackgroundObjects1.length = 0;
gdjs.EditorCode.GDBackgroundObjects2.length = 0;
gdjs.EditorCode.GDfadeObjects1.length = 0;
gdjs.EditorCode.GDfadeObjects2.length = 0;


return;

}

gdjs['EditorCode'] = gdjs.EditorCode;
