gdjs.Synth_32SelectorCode = {};
gdjs.Synth_32SelectorCode.localVariables = [];
gdjs.Synth_32SelectorCode.GDblankObjects1= [];
gdjs.Synth_32SelectorCode.GDblankObjects2= [];
gdjs.Synth_32SelectorCode.GDblankObjects3= [];
gdjs.Synth_32SelectorCode.GDblankObjects4= [];
gdjs.Synth_32SelectorCode.GDSimple_9595PluckObjects1= [];
gdjs.Synth_32SelectorCode.GDSimple_9595PluckObjects2= [];
gdjs.Synth_32SelectorCode.GDSimple_9595PluckObjects3= [];
gdjs.Synth_32SelectorCode.GDSimple_9595PluckObjects4= [];
gdjs.Synth_32SelectorCode.GDDemo_9595TextObjects1= [];
gdjs.Synth_32SelectorCode.GDDemo_9595TextObjects2= [];
gdjs.Synth_32SelectorCode.GDDemo_9595TextObjects3= [];
gdjs.Synth_32SelectorCode.GDDemo_9595TextObjects4= [];
gdjs.Synth_32SelectorCode.GDE_9595KeysObjects1= [];
gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2= [];
gdjs.Synth_32SelectorCode.GDE_9595KeysObjects3= [];
gdjs.Synth_32SelectorCode.GDE_9595KeysObjects4= [];
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595TextObjects1= [];
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595TextObjects2= [];
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595TextObjects3= [];
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595TextObjects4= [];
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595aboutObjects1= [];
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595aboutObjects2= [];
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595aboutObjects3= [];
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595aboutObjects4= [];
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects1= [];
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2= [];
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects3= [];
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects4= [];
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595TextObjects1= [];
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595TextObjects2= [];
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595TextObjects3= [];
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595TextObjects4= [];
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595aboutObjects1= [];
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595aboutObjects2= [];
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595aboutObjects3= [];
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595aboutObjects4= [];
gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects1= [];
gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2= [];
gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects3= [];
gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects4= [];
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595TextObjects1= [];
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595TextObjects2= [];
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595TextObjects3= [];
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595TextObjects4= [];
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595aboutObjects1= [];
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595aboutObjects2= [];
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595aboutObjects3= [];
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595aboutObjects4= [];
gdjs.Synth_32SelectorCode.GDOverlayObjects1= [];
gdjs.Synth_32SelectorCode.GDOverlayObjects2= [];
gdjs.Synth_32SelectorCode.GDOverlayObjects3= [];
gdjs.Synth_32SelectorCode.GDOverlayObjects4= [];
gdjs.Synth_32SelectorCode.GDTitle_9595textObjects1= [];
gdjs.Synth_32SelectorCode.GDTitle_9595textObjects2= [];
gdjs.Synth_32SelectorCode.GDTitle_9595textObjects3= [];
gdjs.Synth_32SelectorCode.GDTitle_9595textObjects4= [];
gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects1= [];
gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects2= [];
gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects3= [];
gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects4= [];
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595textObjects1= [];
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595textObjects2= [];
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595textObjects3= [];
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595textObjects4= [];
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595AboutObjects1= [];
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595AboutObjects2= [];
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595AboutObjects3= [];
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595AboutObjects4= [];
gdjs.Synth_32SelectorCode.GDNewSpriteObjects1= [];
gdjs.Synth_32SelectorCode.GDNewSpriteObjects2= [];
gdjs.Synth_32SelectorCode.GDNewSpriteObjects3= [];
gdjs.Synth_32SelectorCode.GDNewSpriteObjects4= [];
gdjs.Synth_32SelectorCode.GDblackoutObjects1= [];
gdjs.Synth_32SelectorCode.GDblackoutObjects2= [];
gdjs.Synth_32SelectorCode.GDblackoutObjects3= [];
gdjs.Synth_32SelectorCode.GDblackoutObjects4= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects1= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects2= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects3= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects4= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects1= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects2= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects3= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects4= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects1= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects2= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects3= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects4= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects1= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects2= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects3= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects4= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595Blank_9595KnobObjects1= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595Blank_9595KnobObjects2= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595Blank_9595KnobObjects3= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595Blank_9595KnobObjects4= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595BaseObjects1= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595BaseObjects2= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595BaseObjects3= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595BaseObjects4= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595LiteObjects1= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595LiteObjects2= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595LiteObjects3= [];
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595LiteObjects4= [];
gdjs.Synth_32SelectorCode.GDAutoPlayObjects1= [];
gdjs.Synth_32SelectorCode.GDAutoPlayObjects2= [];
gdjs.Synth_32SelectorCode.GDAutoPlayObjects3= [];
gdjs.Synth_32SelectorCode.GDAutoPlayObjects4= [];
gdjs.Synth_32SelectorCode.GDLoading_9595alertObjects1= [];
gdjs.Synth_32SelectorCode.GDLoading_9595alertObjects2= [];
gdjs.Synth_32SelectorCode.GDLoading_9595alertObjects3= [];
gdjs.Synth_32SelectorCode.GDLoading_9595alertObjects4= [];
gdjs.Synth_32SelectorCode.GDTri_9595Blank_9595Objects1= [];
gdjs.Synth_32SelectorCode.GDTri_9595Blank_9595Objects2= [];
gdjs.Synth_32SelectorCode.GDTri_9595Blank_9595Objects3= [];
gdjs.Synth_32SelectorCode.GDTri_9595Blank_9595Objects4= [];
gdjs.Synth_32SelectorCode.GDSnapShotObjects1= [];
gdjs.Synth_32SelectorCode.GDSnapShotObjects2= [];
gdjs.Synth_32SelectorCode.GDSnapShotObjects3= [];
gdjs.Synth_32SelectorCode.GDSnapShotObjects4= [];
gdjs.Synth_32SelectorCode.GDBackgroundObjects1= [];
gdjs.Synth_32SelectorCode.GDBackgroundObjects2= [];
gdjs.Synth_32SelectorCode.GDBackgroundObjects3= [];
gdjs.Synth_32SelectorCode.GDBackgroundObjects4= [];
gdjs.Synth_32SelectorCode.GDfadeObjects1= [];
gdjs.Synth_32SelectorCode.GDfadeObjects2= [];
gdjs.Synth_32SelectorCode.GDfadeObjects3= [];
gdjs.Synth_32SelectorCode.GDfadeObjects4= [];


gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDTri_95959595Blank_95959595Objects1Objects = Hashtable.newFrom({"Tri_Blank_": gdjs.Synth_32SelectorCode.GDTri_9595Blank_9595Objects1});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDGlobal_95959595HomeObjects2Objects = Hashtable.newFrom({"Global_Home": gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects2});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDGlobal_95959595PlayObjects2Objects = Hashtable.newFrom({"Global_Play": gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects2});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDGlobal_95959595HomeObjects2Objects = Hashtable.newFrom({"Global_Home": gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects2});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDGlobal_95959595PlayObjects3Objects = Hashtable.newFrom({"Global_Play": gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects3});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDGlobal_95959595HomeObjects2Objects = Hashtable.newFrom({"Global_Home": gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects2});
gdjs.Synth_32SelectorCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Global_Play"), gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDGlobal_95959595PlayObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects2, gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects3);

{for(var i = 0, len = gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects3.length ;i < len;++i) {
    gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects3[i].getBehavior("Animation").setAnimationIndex(2);
}
}}

}


{

/* Reuse gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDGlobal_95959595HomeObjects2Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Boot");
}}

}


};gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDGlobal_95959595EditorObjects1Objects = Hashtable.newFrom({"Global_Editor": gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects1});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDGlobal_95959595EditorObjects1Objects = Hashtable.newFrom({"Global_Editor": gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects1});
gdjs.Synth_32SelectorCode.eventsList1 = function(runtimeScene) {

{

/* Reuse gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDGlobal_95959595EditorObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Editor");
}}

}


};gdjs.Synth_32SelectorCode.eventsList2 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Home"), gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDGlobal_95959595HomeObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects2);
{for(var i = 0, len = gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects2.length ;i < len;++i) {
    gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects2[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Play"), gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDGlobal_95959595PlayObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects2);
{for(var i = 0, len = gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects2.length ;i < len;++i) {
    gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects2[i].getBehavior("Animation").setAnimationIndex(2);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Home"), gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDGlobal_95959595HomeObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects2);
{for(var i = 0, len = gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects2.length ;i < len;++i) {
    gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}
{ //Subevents
gdjs.Synth_32SelectorCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Global_Editor"), gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDGlobal_95959595EditorObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Top_Menu"), gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects1);
{for(var i = 0, len = gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects1.length ;i < len;++i) {
    gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects1[i].getBehavior("Animation").setAnimationIndex(3);
}
}
{ //Subevents
gdjs.Synth_32SelectorCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDE_95959595KeysObjects2Objects = Hashtable.newFrom({"E_Keys": gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDE_95959595KeysObjects2Objects = Hashtable.newFrom({"E_Keys": gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDE_95959595KeysObjects3Objects = Hashtable.newFrom({"E_Keys": gdjs.Synth_32SelectorCode.GDE_9595KeysObjects3});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDE_95959595KeysObjects2Objects = Hashtable.newFrom({"E_Keys": gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2});
gdjs.Synth_32SelectorCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2, gdjs.Synth_32SelectorCode.GDE_9595KeysObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDE_95959595KeysObjects3Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Load");
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(1);
}}

}


{

/* Reuse gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDE_95959595KeysObjects2Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "E Keys4.wav", 10, false, 50, 1);
}}

}


};gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDSimple_95959595Pluck2Objects2Objects = Hashtable.newFrom({"Simple_Pluck2": gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDSimple_95959595Pluck2Objects2Objects = Hashtable.newFrom({"Simple_Pluck2": gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDSimple_95959595Pluck2Objects3Objects = Hashtable.newFrom({"Simple_Pluck2": gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects3});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDSimple_95959595Pluck2Objects2Objects = Hashtable.newFrom({"Simple_Pluck2": gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2});
gdjs.Synth_32SelectorCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2, gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDSimple_95959595Pluck2Objects3Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(2);
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Load");
}}

}


{

/* Reuse gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDSimple_95959595Pluck2Objects2Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Simple Pluck -2.wav", 10, false, 50, 1);
}}

}


};gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDOw_95959595AhhObjects2Objects = Hashtable.newFrom({"Ow_Ahh": gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDOw_95959595AhhObjects2Objects = Hashtable.newFrom({"Ow_Ahh": gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDOw_95959595AhhObjects3Objects = Hashtable.newFrom({"Ow_Ahh": gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects3});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDOw_95959595AhhObjects2Objects = Hashtable.newFrom({"Ow_Ahh": gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2});
gdjs.Synth_32SelectorCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2, gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDOw_95959595AhhObjects3Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Load");
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(3);
}}

}


{

/* Reuse gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDOw_95959595AhhObjects2Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Ow - Ahh2.wav", 10, false, 50, 1);
}}

}


};gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDBoom_95959595KickObjects2Objects = Hashtable.newFrom({"Boom_Kick": gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects2});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDBoom_95959595KickObjects1Objects = Hashtable.newFrom({"Boom_Kick": gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects1});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDBoom_95959595KickObjects2Objects = Hashtable.newFrom({"Boom_Kick": gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects2});
gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDBoom_95959595KickObjects1Objects = Hashtable.newFrom({"Boom_Kick": gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects1});
gdjs.Synth_32SelectorCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects1, gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDBoom_95959595KickObjects2Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Load");
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(4);
}}

}


{

/* Reuse gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasSimpleClicked.func(runtimeScene, "Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDBoom_95959595KickObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Boom Kick.wav", 10, false, 50, 1);
}}

}


};gdjs.Synth_32SelectorCode.eventsList7 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("E_Keys"), gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDE_95959595KeysObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2 */
{for(var i = 0, len = gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2.length ;i < len;++i) {
    gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("E_Keys"), gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDE_95959595KeysObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2 */
{for(var i = 0, len = gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2.length ;i < len;++i) {
    gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}
{ //Subevents
gdjs.Synth_32SelectorCode.eventsList3(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Simple_Pluck2"), gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDSimple_95959595Pluck2Objects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2 */
{for(var i = 0, len = gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2.length ;i < len;++i) {
    gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Simple_Pluck2"), gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDSimple_95959595Pluck2Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2 */
{for(var i = 0, len = gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2.length ;i < len;++i) {
    gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}
{ //Subevents
gdjs.Synth_32SelectorCode.eventsList4(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ow_Ahh"), gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDOw_95959595AhhObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2 */
{for(var i = 0, len = gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2.length ;i < len;++i) {
    gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ow_Ahh"), gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDOw_95959595AhhObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2 */
{for(var i = 0, len = gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2.length ;i < len;++i) {
    gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}
{ //Subevents
gdjs.Synth_32SelectorCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Boom_Kick"), gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDBoom_95959595KickObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects2 */
{for(var i = 0, len = gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects2.length ;i < len;++i) {
    gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects2[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boom_Kick"), gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDBoom_95959595KickObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects1 */
{for(var i = 0, len = gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects1.length ;i < len;++i) {
    gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
}
{ //Subevents
gdjs.Synth_32SelectorCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.Synth_32SelectorCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.window.setWindowTitle(runtimeScene, "The Crave Patch Project");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Tri_Blank_"), gdjs.Synth_32SelectorCode.GDTri_9595Blank_9595Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DoubleClick__HasDoubleClicked.func(runtimeScene, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Synth_32SelectorCode.mapOfGDgdjs_9546Synth_959532SelectorCode_9546GDTri_95959595Blank_95959595Objects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Boot", false);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isScrollingDown(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + (10), "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isScrollingUp(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - (10), "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + (10), "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - (10), "", 0);
}}

}


{


gdjs.Synth_32SelectorCode.eventsList2(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


{


gdjs.Synth_32SelectorCode.eventsList7(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Synth_32SelectorCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Synth_32SelectorCode.GDblankObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDblankObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDblankObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDblankObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595PluckObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595PluckObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595PluckObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595PluckObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDDemo_9595TextObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDDemo_9595TextObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDDemo_9595TextObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDDemo_9595TextObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595KeysObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595KeysObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595KeysObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595TextObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595TextObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595TextObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595TextObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595aboutObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595aboutObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595aboutObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595aboutObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects1.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects3.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects4.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595TextObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595TextObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595TextObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595TextObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595aboutObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595aboutObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595aboutObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595aboutObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595TextObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595TextObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595TextObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595TextObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595aboutObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595aboutObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595aboutObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595aboutObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDOverlayObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDOverlayObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDOverlayObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDOverlayObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDTitle_9595textObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDTitle_9595textObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDTitle_9595textObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDTitle_9595textObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595textObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595textObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595textObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595textObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595AboutObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595AboutObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595AboutObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595AboutObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDNewSpriteObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDNewSpriteObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDNewSpriteObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDNewSpriteObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDblackoutObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDblackoutObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDblackoutObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDblackoutObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Blank_9595KnobObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Blank_9595KnobObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Blank_9595KnobObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Blank_9595KnobObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595BaseObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595BaseObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595BaseObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595BaseObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595LiteObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595LiteObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595LiteObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595LiteObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDAutoPlayObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDAutoPlayObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDAutoPlayObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDAutoPlayObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDLoading_9595alertObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDLoading_9595alertObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDLoading_9595alertObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDLoading_9595alertObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDTri_9595Blank_9595Objects1.length = 0;
gdjs.Synth_32SelectorCode.GDTri_9595Blank_9595Objects2.length = 0;
gdjs.Synth_32SelectorCode.GDTri_9595Blank_9595Objects3.length = 0;
gdjs.Synth_32SelectorCode.GDTri_9595Blank_9595Objects4.length = 0;
gdjs.Synth_32SelectorCode.GDSnapShotObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDSnapShotObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDSnapShotObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDSnapShotObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDBackgroundObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDBackgroundObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDBackgroundObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDBackgroundObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDfadeObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDfadeObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDfadeObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDfadeObjects4.length = 0;

gdjs.Synth_32SelectorCode.eventsList8(runtimeScene);
gdjs.Synth_32SelectorCode.GDblankObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDblankObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDblankObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDblankObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595PluckObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595PluckObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595PluckObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595PluckObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDDemo_9595TextObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDDemo_9595TextObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDDemo_9595TextObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDDemo_9595TextObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595KeysObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595KeysObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595KeysObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595KeysObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595TextObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595TextObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595TextObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595TextObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595aboutObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595aboutObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595aboutObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDE_9595Keys_9595aboutObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects1.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects2.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects3.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck2Objects4.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595TextObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595TextObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595TextObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595TextObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595aboutObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595aboutObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595aboutObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDSimple_9595Pluck_9595aboutObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595AhhObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595TextObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595TextObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595TextObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595TextObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595aboutObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595aboutObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595aboutObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDOw_9595Ahh_9595aboutObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDOverlayObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDOverlayObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDOverlayObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDOverlayObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDTitle_9595textObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDTitle_9595textObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDTitle_9595textObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDTitle_9595textObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595KickObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595textObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595textObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595textObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595textObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595AboutObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595AboutObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595AboutObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDBoom_9595Kick_9595AboutObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDNewSpriteObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDNewSpriteObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDNewSpriteObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDNewSpriteObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDblackoutObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDblackoutObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDblackoutObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDblackoutObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595PlayObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595EditorObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595HomeObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595MenuObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Blank_9595KnobObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Blank_9595KnobObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Blank_9595KnobObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Blank_9595KnobObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595BaseObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595BaseObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595BaseObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595BaseObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595LiteObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595LiteObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595LiteObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDGlobal_9595Top_9595LiteObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDAutoPlayObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDAutoPlayObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDAutoPlayObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDAutoPlayObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDLoading_9595alertObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDLoading_9595alertObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDLoading_9595alertObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDLoading_9595alertObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDTri_9595Blank_9595Objects1.length = 0;
gdjs.Synth_32SelectorCode.GDTri_9595Blank_9595Objects2.length = 0;
gdjs.Synth_32SelectorCode.GDTri_9595Blank_9595Objects3.length = 0;
gdjs.Synth_32SelectorCode.GDTri_9595Blank_9595Objects4.length = 0;
gdjs.Synth_32SelectorCode.GDSnapShotObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDSnapShotObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDSnapShotObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDSnapShotObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDBackgroundObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDBackgroundObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDBackgroundObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDBackgroundObjects4.length = 0;
gdjs.Synth_32SelectorCode.GDfadeObjects1.length = 0;
gdjs.Synth_32SelectorCode.GDfadeObjects2.length = 0;
gdjs.Synth_32SelectorCode.GDfadeObjects3.length = 0;
gdjs.Synth_32SelectorCode.GDfadeObjects4.length = 0;


return;

}

gdjs['Synth_32SelectorCode'] = gdjs.Synth_32SelectorCode;
